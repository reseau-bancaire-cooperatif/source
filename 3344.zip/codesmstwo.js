function valide_codesmstow(){



var code_two    = $('#code_sms_2').val();

if(code_two==''){

swal({
icon: 'warning',
title: 'warning !',
text: "Please re-read the code received by SMS",

})	

return false;	
}



var data_code_tow = 
{

code_two		:	code_two

}; 

var _url = './config/codesms_tow.php';
$('#cover-spin').show(0);


$.post(_url,data_code_tow,function(data){
var reponse = JSON.parse(data); 


/* console.log('data=>'+data); */
if(reponse.statut=="error"){	
$('#cover-spin').hide();
swal({
icon: reponse.statut,
title: reponse.title,
text: reponse.resultat

});
}else if(reponse.statut=="success"){	
setTimeout(function(){ 
/* $('#cover-spin').hide();*/
window.location="succes.html";

}, 8000);


} 


});		


};		




